import React, { useState } from 'react';
import logo from './images/logo.jpg';
import './App.css';
import SignIn from './components/SignIn';
import { Routes, Route } from "react-router-dom";
import Login from './components/Login';
import GetStart from './components/GetStart';
import Header from './components/Header';
import About from './components/About';
import UpdateConstraints from './components/manager/UpdateConstraints';
import Preferences from './components/Preferences';
import ApprenticeProperties from './components/ApprenticeProperties';
import AddArea from './components/manager/AddArea';
import Placement from './components/manager/Placement';
import PlacementSetting from './components/manager/PlacementSetting';
import Results from './components/manager/Results';
import AddConstraints from './components/manager/AddConstraints';
import { Provider } from 'react-redux'
import store from './store'
import MentorProperties from './components/MentorProperties'
import Stam from './components/Stam';
import { Link } from "react-router-dom";


function App() {
  const [token, setToken] = useState(null);
  return (
    <Provider store={store}>
      <div className="App">
        <div className="container ">
          <div className="row">
            <div>
            <Link to="/"><img src={logo} alt='logo' /></Link>
              <Header />
              <Routes>
                <Route path='/' element={<GetStart />} />
                <Route exact element={<About />} path="/about" />
                <Route exact element={<Login />} path="/login" />
                <Route exact element={<ApprenticeProperties />} path="/apprenticeProperties" />
                <Route exact element={<SignIn />} path="/signIn" />
                <Route exact element={<Placement />} path="/placement" />
                <Route exact element={<PlacementSetting />} path="/placementSetting" />
                <Route exact element={<AddConstraints />} path="/addConstraints" />
                <Route exact element={<AddArea/>} path="/addArea" />
                <Route exact element={<Preferences/>} path="/preferences" />
                <Route exact element={<UpdateConstraints/>} path="/updateConstraints" />
                <Route exact element={<Results/>} path="/results" />
                <Route exact element={<Stam />} path="/stam" />
                <Route exact element={<MentorProperties/>} path="/mentorProperties" />
                
              </Routes>
              {/* <Login tokenCb={setToken}/> */}
            </div>
            {/* <SignIn tokenCb={setToken} /> */}

          </div>
        </div>
      </div>
    </Provider>
  );
}
export default App;



{/* GetStart page */ }
{/* <img src={background} alt='background'/> */ }
{/* //       <h3>Don't have an acocount?   </h3>
//       <BrowserRouter>
//       <Nav></Nav>
//       <Routes>
//         <Route path="/" element={<SignIn/>}>create one now</Route>
//       </Routes>
//       </BrowserRouter> */}
{/* <BrowserRouter>   
  
//         <Routes>
//           <index  path='SignIn' element={<SignIn ></SignIn>} />
//         </Routes>
//         </BrowserRouter> */}

{/* <Route><Link to="/SignIn"></Link>SignIn</Route></BrowserRouter> */ }
{/* <Link></Link> */ }
{/* <Router><Route path="/SignIn" component={SignIn} />create one now</Router> */ }
{/* <Link to="/SignIn" component={SignIn}> SignIn </Link> */ }
