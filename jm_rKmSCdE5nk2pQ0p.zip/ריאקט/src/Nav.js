// import { Link } from "react-router-dom";
// import React from "react";
// export function Nav(){
//     return <div>
//         <Link to="/">
//         <button>create one now</button> 
//         </Link>
//         </div>
// }