import React from "react";

export default () => {
    return (
        <>
            <h1>About yeudit spiner</h1>
            </>
    )
}
