import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';

export default function SliderSizes() {
    const initialList = [];
    const [list, setList] = useState(initialList);
    const dispatch = useDispatch();
    const [selected, setSelected] = useState();
    const TutorID = useSelector(state => state.generalReducer.TutorID);
    const ApprenticeID = useSelector(state => state.generalReducer.ApprenticeID);

    const placementID = useSelector(state => state.generalReducer.placementId);
    const characterization = useSelector(state => state.generalReducer.characterization);
    const constraints = useSelector(state => state.generalReducer.constraints);
    const allCharacterization = useSelector(state => state.generalReducer.allCharacterization);
    const isAppr = useSelector(state => state.generalReducer.isAppr);
    
// const userId1=useSelector(state=>state.generalReducer.TutorID);
// const userId=useSelector(state=>state.generalReducer.ApprenticeID);
// if(userId1===null){

// }

    useEffect(() => {
        dispatch({ type: 'CONSTRAINTS', payload: placementID })
        
          }, []);

    useEffect(() => {
        constraints && constraints.map((x, index) => {
            dispatch({ type: 'CHARACTERIZATION_CONSTRAINTS', payload: { c: x.ConstraintID, index: index } });
        })
    }, [constraints])

    const clickMe = (e) => {
        console.log(list);
        // const arrayOfObj = Object.entries(list).map((e) => { return ({ 'characterizationConstraintId': e[1].CharacterizationConstraintsId, 'status': e[1].selected}) });
        if (isAppr) {
            dispatch({ type: 'SAVE_APPR_CONSTRAINT', list: list, placementID: placementID })
        }
        else {
            dispatch({ type: 'SAVE_TUTOR_CONSTRAINT', list: list, placementID: placementID })
        }

    }
    return (<>
        {/* {constraints ? constraints.map((x, index) => {
            dispatch({ type: 'CHARACTERIZATION_CONSTRAINTS', payload: { c: x.ConstraintID, index: index } }); */}
        {
            // characterization &&
            //     characterization.map(y => <Box width={200}>{y.ConstraintName}
            //         <Slider defaultValue={3} aria-label="Default" valueLabelDisplay="auto" min={1} max={5} /></Box>)
        }
        {/* }) : ''} */}
        {

            allCharacterization && allCharacterization.map(y => {
                return (
                    <div>
                        {/* {console.log("+++++++++++++++" + y)} */}
                        {y && y[0] ?
                            constraints.find(i => i.ConstraintID === y[0].ConstarintId).ConstraintName
                            : ""}
                        {y.map((x, index) => {
                            return (
                                <Box width={200} key={index}>{x.Value}
                                    <Slider
                                        defaultValue={1}
                                        aria-label="Default"
                                        valueLabelDisplay="auto"
                                        min={1}
                                        max={5}
                                        onChange={(event => {
                                            setSelected(event.target.value)
                                            if (TutorID == null)
                                            {
                                                const newList = list.concat({'CharacterizationConstrainId':x.CharacterizationConstraintsId, 'ConstraintID': x.ConstarintId,'ApprenticeID':ApprenticeID, 'Status': event.target.value });
                                                setList(newList);
                                            }
                                            else {
                                                const newList = list.concat({'CharacterizationConstrainId':x.CharacterizationConstraintsId, 'ConstraintID': x.ConstarintId,'TutorID':TutorID, 'Status': event.target.value });
                                                setList(newList);
                                            }
                                        }
                                        )}
                                    // })}
                                    />
                                </Box>)
                        })}
                      
                    </div>

                )
            })
        }

<div>
                            <button className="btn btn-primery" type="submit" onClick={(e) => clickMe(e)}>ok</button>
                        </div>
    </>);
}
// constraints ? constraints.map(x =><div className="col-6"> <SearchSlider onChange={onChange} name={x.ConstrainName} /></div>




