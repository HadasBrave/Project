import React from "react"
import background from '../images/background.jpg'
import { Link } from "react-router-dom";
export default () => {
    return (
        <div>
            <Link to="/login"><img src={background} alt='background' /></Link>
            <h3>Don't have an acocount? <Link to="/signIn">
                Create one now
            </Link>
            </h3>
        </div>);
}
