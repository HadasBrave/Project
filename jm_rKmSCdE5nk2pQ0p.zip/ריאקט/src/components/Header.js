import React from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

export default () => {
    const dispatch = useDispatch();
    const log = useSelector(state => state.generalReducer.isLog);
    const tutor = useSelector(state => state.generalReducer.isTutor);
    const appr = useSelector(state => state.generalReducer.isAppr);
    const Reset = () => {
        log = false;
    }
    // const refreshPage=()=>{
    //     window.location.reload();
    // }
    //onClick={refreshPage}
    if (log == false) {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-12">
                        <nav className="navbar navbar-expand-lg navbar-light bg-light">
                            <div className="collapse navbar-collapse" id="navbarNav">
                                <ul className="navbar-nav">
                                    <li className="nav-item active">
                                        <Link className="nav-link" to="/about">
                                            About
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/login">
                                            Login
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        )
    }
    else if (tutor == true) {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-12">
                        <nav className="navbar navbar-expand-lg navbar-light bg-light">
                            <div className="collapse navbar-collapse" id="navbarNav">
                                <ul className="navbar-nav">

                                    <li className="nav-item active">
                                        <Link className="nav-link" to="/about">
                                            About
                                        </Link>
                                    </li>
                                    <li className="nav-item active">
                                        <Link className="nav-link" to="/apprenticeProperties">
                                            Properties
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/preferences">
                                            Preferences
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/" onClick={Reset}>
                                            LogOut
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        )
    }
    else if (appr == true) {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-12">
                        <nav className="navbar navbar-expand-lg navbar-light bg-light">
                            <div className="collapse navbar-collapse" id="navbarNav">
                                <ul className="navbar-nav">
                                    <li className="nav-item active">
                                        <Link className="nav-link" to="/apprenticeProperties">
                                            ApprenticeProperties
                                        </Link>
                                    </li>
                                    <li className="nav-item active">
                                        <Link className="nav-link" to="/about">
                                            About
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/preferences">
                                            Preferences
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/" onClick={Reset}>
                                            LogOut
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        )
    }
    else {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div className="col-12">
                        <nav className="navbar navbar-expand-lg navbar-light bg-light">
                            <div className="collapse navbar-collapse" id="navbarNav">
                                <ul className="navbar-nav">
                                    <li className="nav-item active">
                                        <Link className="nav-link" to="/placement">
                                            Placement
                                        </Link>
                                    </li>
                                    <li className="nav-item active">
                                        <Link className="nav-link" to="/placementSetting">
                                            Placement Setting
                                        </Link>
                                    </li>
                                    <li className="nav-item active">
                                        <Link className="nav-link" to="/addConstraints">
                                            Add Constraints
                                        </Link>
                                    </li>
                                    <li className="nav-item active">
                                        <Link className="nav-link" to="/updateConstraints">
                                            Update Constraints
                                        </Link>
                                    </li>
                                    <li className="nav-item active">
                                        <Link className="nav-link" to="/results">
                                            Results
                                        </Link>
                                    </li>
                                    <li className="nav-item active">
                                        <Link className="nav-link" to="/about">
                                            About
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/" onClick={Reset}>
                                            LogOut
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        )
    }

}