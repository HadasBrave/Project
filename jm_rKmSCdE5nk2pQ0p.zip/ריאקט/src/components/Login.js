import React, { useEffect } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from 'yup';
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { type } from "@testing-library/user-event/dist/type";

const LoginSchema = Yup.object().shape(
  {
    userName: Yup.string().required('name is required'),
    password: Yup.string().required('password is required')
  }
)

// const f = () => {

// }
export default () => {
  const dispatch = useDispatch();
  const navigate = useNavigate()
  //const userData = useSelector(state => state.generalReducer.userData);
  const isTutor = useSelector(state=>state.generalReducer.isTutor);
  const isAppr= useSelector(state=>state.generalReducer.isAppr);
  const login = async (value) => {
    dispatch({ type: 'LOG' })
    dispatch({ type: 'LOGIN', value })
    dispatch({ type: 'PLACEMENT_ID_BY_USERID', value })
    // dispatch({ type: 'PLACEMENT', value })
    
  
    // if (isAppr) {
    //   dispatch({ type: 'I_AM_APPR' })
    // }
    // else if (isTutor) {
    //   dispatch({ type: 'I_AM_TUTOR' })
    // }
    // else {
    //   dispatch({ type: 'I_AM_MANAGER' })
    // }
    navigate('/about')
  }
  return (
    <Formik
      initialValues={{ userName: '', password: '' }}
      onSubmit={value => login(value)}
      validationSchema={LoginSchema}
    >
      <Form>
        <h1>Login</h1>
        <div className="form-group">
          <Field
            placeholder="name"
            className="form-control"
            type="text"
            name="userName" />
          <ErrorMessage
            className="alert alert-danger"
            component="div"
            name="userName"
            value=""
          />
        </div>
        <div className="form-group">
          <Field
            placeholder="password"
            className="form-control"
            type="password"
            name="password"
          />
          <ErrorMessage
            className="alert alert-danger"
            component="div"
            name="password"
            value=""

          />
        </div>
        <div className="form-group">
          <button className="btn btn-primery" type="submit">ok</button>
        </div>
      </Form>
    </Formik>
  )
}