
import React from "react";
import Typography from '@mui/material/Typography';
import Slider from '@mui/material/Slider';


const SearchSlider = ({ onChange, name }) => {
    const [numPlayers, setNumPlayers] = React.useState(3);

    const handlePlayersChange = (event, newValue) => {
        setNumPlayers(newValue);
        onChange({ name, newValue });
    };

    return (
        <div className="slidecontainer">
            <Typography id="range-slider" gutterBottom>
                {name}
            </Typography>
            <Slider
                className="slider"
                min={1}
                max={5}
                name={name}
                value={numPlayers}
                onChange={handlePlayersChange}
                valueLabelDisplay="auto"
                aria-labelledby="range-slider"

            />
        </div>
    );
};
export default function SearchForm() {
    const [numPlayersBySliders, setNumPlayersBySliders] = React.useState([]);

    const handleSubmit = (event) => {
        event.preventDefault();
    };

    const onChange = ({ newValue, name }) => {
        const clearState = numPlayersBySliders.filter(s => s.name !== name);
        const newItem = { name, numPlayers: newValue };
        setNumPlayersBySliders([...clearState, newItem]);
        console.log(numPlayersBySliders);
    };

    return (
        <form onSubmit={handleSubmit}>
            <h1>Mark from 1-5 how much you are in:</h1>
            <div className="slidecontainer">
                <div className="row">
                    <div className="col-6">
                        <SearchSlider onChange={onChange} name="Math" />
                    </div>
                    <div className="col-6">
                        <SearchSlider onChange={onChange} name="English" />
                    </div>
                    <div className="col-6">
                        <SearchSlider onChange={onChange} name="ReadingComprehension" />
                    </div>
                    <div className="col-6">
                        <SearchSlider onChange={onChange} name="Happy" />
                        </div>
                    <div className="col-6">
                        <SearchSlider onChange={onChange} name="Sad" />
                        </div>  
                    <div className="col-6">
                        <SearchSlider onChange={onChange} name="Friendly" />
                  </div>  </div>
                </div>
                <button>Search</button>
        </form>
    );
}