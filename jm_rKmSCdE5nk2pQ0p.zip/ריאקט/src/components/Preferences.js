import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';
import { Form, Formik } from "formik";

export default () => {
    const initialList = [];
    const [list, setList] = useState(initialList);
    const isAppr = useSelector(state => state.generalReducer.isAppr);
    const dispatch = useDispatch();
    const [status, setStatus] = useState();
    const placementID = useSelector(state => state.generalReducer.placementId);
    const ApprenticeID = useSelector(state => state.generalReducer.ApprenticeID);
    const TutorID = useSelector(state => state.generalReducer.TutorID);


    const [rangeNum, setRangeNum] = useState();
    const preference = useSelector(state => state.generalReducer.preference);

    useEffect(() => {
        dispatch({ type: 'PREFERENCE', payload: placementID })
    }, [])

    const preferences = (e) => {
        console.log(list);
        // const arrayOfObj = Object.entries(list).map((e) => { return ({ 'prefrenceId': e[1].PreferenceID, 'status': e[1].status }) });
        if (isAppr) {
            dispatch({ type: 'SAVE_APPR_PREFERENCE', list: list})
        }
        else {
            dispatch({ type: 'SAVE_TUTOR_PREFERENCE', list: list })
        }
        // value = { ...value, pref:pref };
        // dispatch({ type: 'APPR_PREFERENCE', pref:pref })
        // console.log(pref);
    }
    return (
        <>
            <Formik
            
            >
               
      <Form onSubmit={(e) => { e.preventDefault(); preferences(list) }}>

                
                    <h1>Preferences</h1>
                    {
                        preference && preference.map(x => {
                            // const newPref = { name: x.PreferenceName, id: x.PreferenceID, range: 3 };
                            // y.push(newPref)
                            return (
                                <div>
                                    <Box width={200}>{x.PreferenceName}
                                        <Slider
                                            // value={status}
                                            defaultValue={1}
                                            aria-label="Default"
                                            valueLabelDisplay="auto"
                                            min={1}
                                            max={5}
                                            // name={x.PreferenceName}
                                            onChange={(event => {
                                                setStatus(event.target.value)
                                                if (ApprenticeID == null)
                                                {
                                                    const newList = list.concat({ 'apprentinceId':ApprenticeID, 'preferenceId': x.PreferenceID,  'status': event.target.value });
                                                    setList(newList);
                                                }
                                                else {
                                                    const newList = list.concat({  'preferenceId': x.PreferenceID, 'tutorId':TutorID , 'status': event.target.value });
                                                    setList(newList);
                                                }

                                                // setRangeNum(event.target.value)
                                                // list.filter(y => y.name === event.target.name)[0].range = event.target.value;
                                                // pref.filter(y => {
                                                //     if (y.name === event.target.name) {
                                                //         y.range = event.target.value;
                                                //     }
                                                //     // [0].range = event.target.value;
                                                // })

                                            }
                                            )}
                                        />
                                    </Box>
                                    {/* {console.log(pref)} */}
                                </div>)
                        })
                    }
                    {/* {list.map((item) => {
                       
                        
                   })} */}
                    <div className="form-group">
                        <button className="btn btn-primery" type="submit" >ok</button>
                    </div>
                </Form>
            </Formik>
        </>)
}