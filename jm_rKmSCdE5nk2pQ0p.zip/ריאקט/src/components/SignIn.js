import React, { useState, useEffect } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import Box from '@mui/material/Box';
import * as Yup from 'yup';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import store from "../store";
import { setCityId, setCityN } from "../reducer";
const ShignSchema = Yup.object().shape(
  {
    userName: Yup.string().required('Name is required'),
    Password: Yup.string().required('Password is required'),
    Age: Yup.string().required('Age is required'),
    Phone: Yup.string().required('Phone is required'),
  }
)

export default () => {

  const dispatch = useDispatch();
  const cities = useSelector(state => state.generalReducer.cities);
  const pName = useSelector(state => state.generalReducer.pName);
  const areas = useSelector(state => state.generalReducer.areas);
  // const cityId = useSelector(state => state.generalReducer.cityId);
  // const cityN = useSelector(state => state.generalReducer.city);
const addAreaPage=useSelector(state => state.generalReducer.addAreaPage);
  const navigate = useNavigate()

  useEffect(() => {
    dispatch({ type: 'CITY_DATA_MID' });
    dispatch({ type: 'P_NAME' });
    console.log(pName);
    console.log(cities);
  }, []);
  const [placement, setPlacement] = useState('');
  const [city, setCity] = useState('');
  const [area, setArea] = useState('');
  const [status, setStatus] = useState('');
  // const [city, setStatus] = useState('');
  // const [status, setStatus] = useState('');

  const sighnIn = (value, event) => {
    // להגדיר גם placement city
    dispatch({ type: 'LOG' })
    value = { ...value, Status: status, Placement: placement, City: city, Area: area };
    if (value.Status === 'tutor') {
      dispatch({ type: 'SIGN_IN_TUTOR', payload: value })
    }
    else {
      dispatch({ type: 'SIGN_IN_APPR', payload: value })
    }
    navigate('/apprenticeProperties')

  }
  const handleChange1 = (event) => {
    console.log(("====" + event.target.value));
    if (event.target.value === 'tutor') {
      dispatch({ type: 'I_AM_TUTOR' })
    }
    else {
      dispatch({ type: 'I_AM_APPR' })
    }
    setStatus(event.target.value);

  };
  const handleChange2 = (event) => {
    setPlacement(event.target.value);
  };

  return (
    <Formik
      initialValues={{ userName: '', Password: '', Age: '', Phone: '', Status: status, Placement: placement, City: city, Area: area }}
      onSubmit={(value, event) => sighnIn(value, event)}
      validationSchema={ShignSchema}
    >
      <Form>
        <h1>Sign In</h1>
        <div className="form-group">
          <Field
            placeholder="Name"
            className="form-control"
            type="text"
            name="userName" />
          <ErrorMessage
            className="alert alert-danger"
            component="div"
            name="userName"
            value=""
          />
        </div>
        <div className="form-group">
          <Field
            placeholder="Password"
            className="form-control"
            type="Password"
            name="Password" />
          <ErrorMessage
            className="alert alert-danger"
            component="div"
            name="Password"
            value=""
          />
        </div>
        <div className="form-group">
          <Field
            placeholder="Age"
            className="form-control"
            type="number"
            name="Age" />
          <ErrorMessage
            className="alert alert-danger"
            component="div"
            name="Age"
            value=""
          />
        </div>
        <div className="form-group">
          <Field
            placeholder="Phone"
            className="form-control"
            type="Phone"
            name="Phone"
          />
          <ErrorMessage
            className="alert alert-danger"
            component="div"
            name="Phone"
            value=""
          />
        </div>
        <div>
          <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
            <InputLabel id="demo-select-small">status</InputLabel>
            <Select
              labelId="demo-select-small"
              id="demo-select-small"
              // value=""
              label="status"
              onChange={handleChange1}
              name="Status"
            >
              <MenuItem value={'tutor'}>tutor</MenuItem>
              <MenuItem value={'apprentice'}>apprentice</MenuItem>
            </Select>
          </FormControl>
        </div>

        <div>
          <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
            <InputLabel id="demo-select-small">Placement</InputLabel>
            <Select
              labelId="demo-select-small"
              id="demo-select-small"
              value={placement}
              onChange={(e) => handleChange2(e)}
              label="placment"
              name="Placement"
            >
              {
                pName ? pName.map(x => (<MenuItem value={x.PlacementID}>{x.PlacementName}</MenuItem>)) : ''
              }
            </Select>
          </FormControl>
        </div>

        <div>
          <FormControl fullWidth>
            <InputLabel id="demo-simple-select-label">You live in City:</InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={city}
              // cityId={city}
              onChange={(e, value) => {
                setCity(e.target.value);
                dispatch({ type: 'AREA_DATA_MID', payload: { value: e.target.value, payload: value.props.children } });
              }}
              label="placement in City" >
              {
                cities ? cities.map(x => (<MenuItem value={x.CityId}>{x.CityName}</MenuItem>)) : ''
              }
            </Select>
          </FormControl>

          <Box sx={{ minWidth: 120 }}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">in Areas:</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={area}
                onChange={e => {
                  setArea(e.target.value)
                }}
                label="placement in Area" >
                {
                  areas ? areas.map(x => (<MenuItem value={x.AreaID}>{x.AreaName}</MenuItem>)) : ''
                }
              </Select>
            </FormControl>
          </Box>
        </div>
        <div>
          <button className="btn btn-primery" type="submit">ok</button>
        </div>
        <h5>Can not find an area?<Link to="/addArea" >
          Add new
        </Link>   </h5>
      </Form>
    </Formik>

  );
}