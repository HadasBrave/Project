

// import React, { useState, useEffect } from "react";
// import { Formik, Form, Field, ErrorMessage } from "formik";
// import Box from '@mui/material/Box';
// import * as Yup from 'yup';
// import InputLabel from '@mui/material/InputLabel';
// import MenuItem from '@mui/material/MenuItem';
// import FormControl from '@mui/material/FormControl';
// import Select from '@mui/material/Select';
// import { Link } from "react-router-dom";
// import { useDispatch, useSelector } from "react-redux";
// import { useNavigate } from "react-router-dom";
// import store from "../store";
// import { setCityId, setCityN } from "../reducer";

// export default () => {
//     const dispatch = useDispatch();
//   const cities = useSelector(state => state.generalReducer.cities);
 
//   useEffect(() => {
//     dispatch({ type: 'CITY_DATA_MID' });
//     const arrayOfObj = Object.entries(cities).map((e) => { return ({ 'CityId': e[1].CityId, 'CityName': e[1].CityName}) });
   
//     console.log(arrayOfObj);
//   }, []);
//   const [city, setCity] = useState('');


//   // const data = () => {
   
//   // };
 
//   // set value for default selection
 
//   // handle onChange event of the dropdown
//   // const handleChange = (e) => {
//   //   setSelectedValue(Array.isArray(e) ? e.map(x => x.value) : []);
//   // }
 
//   return (
//     <Formik
//     initialValues={{ City: [] }}
  
//     >
//       <Form>
   
//       <FormControl fullWidth>
//             <InputLabel id="demo-simple-select-label">You live in City:</InputLabel>
//             <Select
//               labelId="demo-simple-select-label"
//               id="demo-simple-select"
//           // multiple={true}
//             // isClearable
//             // options={cities}
//             // isMulti
//             // isClearable
//               // cityId={city}
//             onChange={(e, value) => {
//     // setCity(Array.isArray(e) ? e.map(x => x.value) : []);
                
//                 setCity(e.target.value);
//         // const arrayOfObj = Object.entries(cities).map((e) => { return ({ 'CityId': e[1].CityId, 'CityName': e[1].CityName}) });

//               }}
//             label="placement in City" >
            
//             {
//               cities ? cities.map(x =>
               
//                 (<MenuItem value={x.CityId}>{x.CityName}</MenuItem>)) : ''
//               }
//             </Select>
//           </FormControl>

//     </Form>
//   </Formik> );
// }
 

import React, { useState } from 'react';
import Select from 'react-select';
 
function App() {
  const data = [
    {
      value: 1,
      label: "cerulean"
    },
    {
      value: 2,
      label: "fuchsia rose"
    },
    {
      value: 3,
      label: "true red"
    },
    {
      value: 4,
      label: "aqua sky"
    },
    {
      value: 5,
      label: "tigerlily"
    },
    {
      value: 6,
      label: "blue turquoise"
    }
  ];
 
  // set value for default selection
  const [selectedValue, setSelectedValue] = useState([]);
 
  // handle onChange event of the dropdown
  const handleChange = (e) => {
    setSelectedValue(Array.isArray(e) ? e.map(x => x.value) : []);
  }
 
  return (
    <div className="App">
      <h3>Get selected by only value for multi select - <a href="https://www.cluemediator.com">Clue Mediator</a></h3>
 
      <Select
        className="dropdown"
        placeholder="Select Option"
        value={data.filter(obj => selectedValue.includes(obj.value))} // set selected values
        options={data} // set list of the data
        onChange={handleChange} // assign onChange function
        isMulti
        isClearable
      />
 
      {selectedValue && <div style={{ marginTop: 20, lineHeight: '25px' }}>
        <div><b>Selected Value: </b> {JSON.stringify(selectedValue, null, 2)}</div>
      </div>}
    </div>
  );
}
 
export default App;