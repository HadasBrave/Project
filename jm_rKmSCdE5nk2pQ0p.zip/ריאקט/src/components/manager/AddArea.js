import React, { useEffect, useState } from "react";
import { Formik, Form, Field } from "formik";
import { useDispatch, useSelector } from "react-redux";
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { useNavigate } from "react-router-dom";


export default ({ tokenCb }) => {

    const dispatch = useDispatch();
    const cities = useSelector(state => state.generalReducer.cities);
    const cityId = useSelector(state => state.generalReducer.cityId);
    const cityN = useSelector(state => state.generalReducer.cityN);
const addAreaPage=useSelector(state => state.generalReducer.addAreaPage);
const navigate = useNavigate()

    // const AreaName = useSelector(state => state.generalReducer.AreaName);
    useEffect(() => {
        dispatch({ type: 'CITY_DATA_MID' })
        console.log(cities);
    }, []);
    const [city, setCity] = useState('');
    const addArea = (value) => {
        dispatch({ type: 'ADD_AREA', value })
        // if(addAreaPage){
        //     navigate('/placementSetting')
        // }
        // else{
        //     navigate('/signIn')
        // }
    }
    return (
        <div>
            <Formik
                initialValues={{ CityName: cityN, AreaName: '', CityId: cityId }}
                onSubmit={value => addArea(value)}
            >
                <Form>
                    <h2>{cityN}</h2>

                    <div className="form-group">
                        <Field
                            placeholder="Area Name"
                            className="form-control"
                            type="text"
                            name="AreaName" />
                    </div>
                    <div className="form-group">
                        <button className="btn btn-primery" type="submit">ok</button>
                    </div>
                </Form>
            </Formik>
        </div>
    )
}