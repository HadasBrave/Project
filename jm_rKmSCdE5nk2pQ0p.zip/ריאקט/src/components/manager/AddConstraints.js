import React, { useRef, useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { Formik, Form, Field, ErrorMessage } from "formik";
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import Checkbox from '@mui/material/Checkbox';
import { useDispatch, useSelector } from "react-redux";

export default () => {
    const initialList = [];
    const [list, setList] = useState(initialList);
    const [Value, setValue] = useState("");
    const [cName, setCName] = useState();
    const [select, setSelect] = useState();
    const truefalse = useRef();
    const ChooseRange = useRef();
    const dispatch = useDispatch();
    const placementID = useSelector(state => state.generalReducer.placementId);
    const constraintID = useSelector(state => state.generalReducer.constraintID);

    const clickMe = (e) => {
        var myJSON = list;
        console.log(myJSON);
        // const arrayOfObj = Object.entries(list).map((e) => { return ({ 'Value': e[1].name, 'IsOpposit': e[1].select, 'ConstarintId': null }) });
        // console.log("🚀 ~ file: AddConstraints.js ~ line 26 ~ clickMe ~ arrayOfObj", arrayOfObj)

        if (select === "TrueOrFalse") {
            dispatch({ type: 'ADD_CONSTRAINTS', Value: cName, placementID: placementID, list: myJSON, select: 0, constraintID: constraintID })

        }
        else {
            dispatch({ type: 'ADD_CONSTRAINTS', Value: cName, placementID: placementID, list: myJSON, select: 1, constraintID: constraintID })

        }
        console.log(list);
    }

    return (
        <Formik>
            <Form>
                <h1>Add system constraints  </h1>
                <h3>Add New Constraint:</h3>
                <Field
                    placeholder="Constraint Name"
                    className="form-control"
                    type="text"
                    value={cName}
                    onChange={(e) => (setCName(e.target.value))}

                    name="name" />
                <h5>Constraint pattern:</h5>
                <FormLabel id="demo-controlled-radio-buttons-group">
                    <RadioGroup
                        aria-labelledby="demo-controlled-radio-buttons-group"
                        name="controlled-radio-buttons-group">
                        <FormControlLabel ref={truefalse} value="TrueOrFalse" onChange={(e) => (setSelect(e.target.value))} control={<Radio />} label="True/False" />
                        <FormControlLabel ref={ChooseRange} value="ChooseRange" onChange={(e) => (setSelect(e.target.value))} control={<Radio />} label="ChooseRange" />
                    </RadioGroup>
                </FormLabel>
                <div>
                    <input
                        type="text"
                        value={Value}
                        onChange={(event) => (setValue(event.target.value))}
                        onKeyDown={(event => {
                            if (event.key === "Enter") {
                                const newList = list.concat({ CharacterizationConstraintsId: 1, ConstarintId: 1, IsOpposit: false, Value });
                                
                                if (event.target.value !== "") {
                                    setList(newList);
                                    setValue("");
                                }
                            }
                        })}
                    />
                </div>
                <div className="form-group">
                </div>
                {/* [{id:, name:, checked:},{}] */}
                {
                    list.map((item) => {
                        return <div className="aaa">
                            <Checkbox
                                name={item.Value}
                                id={item.id}
                                onChange={event => {
                                    console.log(event.target.name);
                                    console.log(list.filter(x =>console.log(x)));
                                    console.log(list.filter(x => x.Value === event.target.name)[0]);
                                    if (list.filter(x => x.Value === event.target.name)[0].IsOpposit === true) { list.filter(x => x.Value === event.target.name)[0].IsOpposit = false; }
                                    else { list.filter(x => x.Value === event.target.name)[0].IsOpposit = true; }
                                }}
                                inputProps={{ 'aria-label': 'controlled' }}
                            />
                            <label htmlFor={item.id} key={item.id}>{item.Value}</label>
                        </div>;
                    })
                }
                <button className="btn btn-primery" type="button" onClick={(e) => clickMe(e)}>ok</button>
            </Form>
        </Formik>
    );
};