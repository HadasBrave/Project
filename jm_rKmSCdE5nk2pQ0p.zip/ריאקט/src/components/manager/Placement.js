import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { Formik, Form, Field, ErrorMessage } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export default ({ tokenCb }) => {
    const navigate = useNavigate();
    const [date, setDate] = useState(null);
    const dispatch = useDispatch();
  const placementId = useSelector(state => state.generalReducer.placementId);

    const placement = (value) => {
        dispatch({type: 'P_ID',payload:value.PlacementName});
        value = { ...value, Date: date }
        dispatch({ type: 'PLACEMENT', payload: value })
        navigate('/placementSetting')
    }
    // const list = { PlacementName: '', date: '' };
    return (
        <Formik
            initialValues={{ PlacementId: '1', PlacementName: '', Date: date }}
            onSubmit={value => placement(value)}
        >
            <Form>
                <h1>New Placement</h1>
                <Field
                    placeholder="Placement name"
                    className="form-control"
                    type="text"
                    name="PlacementName"
                />
                <div>
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                        <DatePicker
                            label="Choose Date"
                            value={date}
                            onChange={(newValue) => {
                                setDate(newValue);
                            }}
                            renderInput={(params) => <TextField {...params} />}
                            name="Date"
                        />
                    </LocalizationProvider>
                </div>
                <div className="form-group">
                    <button className="btn btn-primery" type="submit" >Next</button>
                </div>
            </Form>
        </Formik>
    )
}