import React, { useEffect, useState } from "react";
import { Formik, Form, Field } from "formik";
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import { useDispatch, useSelector } from "react-redux";
// import cityService from "../../services/city.service";
// import ReactDOM from "react-dom/client";
// import { setCity, setCityId } from "../../reducer";
// import store from "../../store";

export default () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const cities = useSelector(state => state.generalReducer.cities);
  const areas = useSelector(state => state.generalReducer.areas);
  const placementId = useSelector(state => state.generalReducer.placementId);
  const addAreaPage=useSelector(state => state.generalReducer.addAreaPage);

  // const placementID = useSelector(state => state.generalReducer.placementID);
  const initialList = [];
  const initialAreasList = [];
  const [areasList, setAreasList] = useState(initialAreasList);
  const [list, setlist] = useState(initialList);
  // const [placementId, setPlacementId] = useState('');

  useEffect(() => {
    dispatch({ type: 'CITY_DATA_MID' })
  }, []);
  // const initialList = [];
  // const [list, setList] = useState(initialList);

  const [city, setCity] = useState('');
  const [area, setArea] = useState('');

  function placementSetting(areasList){
    debugger
    let arr = areasList.filter(x => x.selected).map(x=>x.id)
    console.log(arr);
    // areasList = {...arr, placementId: placementId};
  dispatch({ type: 'GetAreas', list: arr, placementID: placementId})
    navigate('/addConstraints')
  }
  // const handleChange1 = (event: React.ChangeEvent<HTMLInputElement>) => {

  //   // setChecked([event.target.checked, event.target.checked]);
  // };
  return (
    <Formik
      initialValues={{ City: '1', PlacementName: '' }}
    >
      <Form onSubmit={(e) => { e.preventDefault(); placementSetting(list) }}>
        <h1>Placement Setting</h1>
        <h3>placement in City</h3>
        <Box sx={{ minWidth: 120 }}>
          <FormControl fullWidth>
            <InputLabel id="demo-simple-select-label">Placement in City:</InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={city}
              name="City"
              onChange={(e, value) => {
                setCity(e.target.value);
                dispatch({ type: 'AREA_DATA_MID', payload: { value: e.target.value, payload: value.props.children } });

              }}
              label="placement in City" >
              {
                cities ? cities.map(x => (<MenuItem value={x.CityId}>{x.CityName}</MenuItem>)) : ''
              }
              {/* key={x.cityId} */}
            </Select>
          </FormControl>
        </Box>
        {
          areas ? areas.map(x => {
            const newArea = { id: x.AreaID, selected: false };
            list.push(newArea);
            return (<Box sx={{ display: 'flex', flexDirection: 'column', ml: 3 }}>
              <FormControlLabel
                label={x.AreaName}
                control={<Checkbox
                  name={x.AreaName}
                  id={x.AreaID}
                  onChange={event => {
                    debugger
                    const idAvent = parseInt(event.target.id.substring(0, 1));
                    let index = list.findIndex(y => y.id === idAvent);
                    if (index != -1) {
                      if (list[index].selected === true) {
                        list[index].selected = false
                      }
                      else {
                        list[index].selected = true
                      }
                    }

                  }} />}
              />
            </Box>)
          }) : ''
        }
        <div>
          <h5>Can not find an area?
            <Link to="/addArea">
              Add new
            </Link>   </h5>

        </div>

        <div className="form-group">
          <button className="btn btn-primery" type="submit">Next</button>
        </div>
      </Form>
    </Formik>
  )

}




