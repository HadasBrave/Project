import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import { styled } from '@mui/material/styles';
import Tooltip, { tooltipClasses } from '@mui/material/Tooltip';
export default () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch({ type: 'P_ALL_RESULT' });
    dispatch({ type: 'P_RESULT' });
    dispatch({ type: 'P_NAME' });
  }, []);
  // const pResult = useSelector(state => state.generalReducer.pResult);
  // const pAllResult = useSelector(state => state.generalReducer.pAllResult);
  const pName = useSelector(state => state.generalReducer.pName);
  const allApprentices = useSelector(state => state.generalReducer.allApprentices);
  const allTutors = useSelector(state => state.generalReducer.allTutors);
  const marks = useSelector(state => state.generalReducer.marks);
  const tool = useSelector(state => state.generalReducer.tool);
  const [placement, setPlacement] = useState('');
  function tblShow() {
    return (<></>
    )
  }

  const handleChange2 = (event) => {
    // setPlacement(event.target.value);
    dispatch({ type: 'TBL1', placement: event.target.value });
    dispatch({ type: 'TBL2', placement: event.target.value });
    dispatch({ type: 'TBL3', placement: event.target.value });
    dispatch({ type: 'TOOL', placement: event.target.value });

  };
  // const info=[
  //   {tool ? tool.map()}
  // ];
  return (<>
    <h1>results</h1>
    <div>
      <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
        <InputLabel id="demo-select-small">Placement</InputLabel>
        <Select
          labelId="demo-select-small"
          id="demo-select-small"
          value={placement}
          onChange={(e) => handleChange2(e)}
          label="placment"
          name="Placement"
        >
          {
            pName ? pName.map(x => (<MenuItem value={x.PlacementID}>{x.PlacementName}</MenuItem>)) : ''
          }
        </Select>
      </FormControl>
    </div>
     
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <Tooltip title={tool ? tool.map(x=>(<p>{x}</p>)):''}><TableHead>
          <TableRow>
            
            <TableCell>Apprentice Name</TableCell>
            <TableCell align="right">Tutor Name</TableCell>
            <TableCell align="right">Marks</TableCell>
            
          </TableRow>
        </TableHead></Tooltip>
        <TableBody>
          {allApprentices?.map((row, index) => (
            <TableRow
              key={row}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell align="right">{row.ApprenticeName}</TableCell>
              <TableCell align="right">{allTutors[index].TutorName}</TableCell>
              <TableCell align="right">{marks[index]}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    
  </>)
}     
