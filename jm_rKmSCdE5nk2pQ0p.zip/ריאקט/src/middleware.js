import axios from 'axios';
import { set } from 'date-fns';
import { setUserData, 
    setAllApprentices,setAllTutors,setMarks,setTool,setApprenticeID, setTutorID, setConstraintID, setPResult, setPAllResult, constraints, setCityN, setCityId, setCharacterization, setAreas, setCities, setConstraints, setPlacementId, setPName, setIsAppr, setIsManager, setIsTutor, setIsLog, setAllCharacterization, setPreference } from './reducer';

const middleware = store => next => action => {
    switch (action.type) {
        case 'LOGIN':
            axios.get(`https://localhost:44323/api/user/GetUser/${action.value.userName}/${action.value.password}`)
                .then(result => {
                    console.log(result);
                    store.dispatch(setUserData(result.data.Data));
                    debugger
                    if (action.value.password === 'trickandpick')
                        store.dispatch(setIsManager(true));
                    else if (result.data.Data==false) {
                        store.dispatch(setIsAppr(true));
                        axios.get(`https://localhost:44323/api/apprentice/GetApprenticeByUserNameAndPassword/${action.value.userName}/${action.value.password}`)
                            .then(result => {
                                console.log(result);
                                store.dispatch(setApprenticeID(result.data.Data.ApprenticeID))
                                store.dispatch(setPlacementId(result.data.Data.PlacementId));
                            })
                            .catch(error => {
                                console.log(error);
                            })
                    }
                    else {
                        store.dispatch(setIsTutor(true));
                        axios.get(`https://localhost:44323/api/Tutor/GetTutorByUserNameAndPassword/${action.value.userName}/${action.value.password}`)
                            .then(result => {
                                console.log(result);
                                store.dispatch(setTutorID(result.data.Data.TutorID))
                                store.dispatch(setPlacementId(result.data.Data.PlacementId));
                            })
                            .catch(error => {
                                console.log(error);
                            })
                    }
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'SIGN_IN_TUTOR':
            store.dispatch(setPlacementId(action.payload.Placement));
            axios.post(`https://localhost:44323/api/tutor/Post`, { 'TutorName': action.payload.userName, 'TutorAge': action.payload.Age, 'TutorPhone': action.payload.Phone, 'AreaID': action.payload.Area, 'PasswordID': action.payload.Password, 'CityId': action.payload.City, 'PlacementID': action.payload.Placement })
                .then(result => {
                    console.log(result);
                    store.dispatch(setIsTutor(true));
                    store.dispatch(setUserData(result.data.Data));
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'SIGN_IN_APPR':
            store.dispatch(setPlacementId(action.payload.Placement));
            axios.post(`https://localhost:44323/api/apprentice/Post`, { 'ApprenticeName': action.payload.userName, 'ApprenticeAga': action.payload.Age, 'ApprenticePhone': action.payload.Phone, 'AreaID': action.payload.Area, 'Password': action.payload.Password, 'CityId': action.payload.City, 'PlacementID': action.payload.Placement })
                .then(result => {
                    console.log(result);
                    store.dispatch(setIsAppr(true));
                    store.dispatch(setUserData(result.data.Data));
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'CONSTRAINTS':
            axios.get(`https://localhost:44323/api/Constraints/GetConstraintByPlacement/${action.payload}`).
                then(result => {
                    console.log(result);
                    store.dispatch(setConstraints(result.data.Data))
                    console.log(constraints);
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'CHARACTERIZATION_CONSTRAINTS':
            axios.get(`https://localhost:44323/api/characterizationConstraints/GetCharacterizationConstraints/${action.payload.c}`)
                .then(result => {
                    let arr = [...store.getState().generalReducer.allCharacterization], i = action.payload.index;
                    arr.push(result.data.Data);
                    store.dispatch(setAllCharacterization(arr))
                    console.log("🚀 ~ file: middleware.js ~ line 65 ~ arr", store.getState().generalReducer.allCharacterization)
    })
                    // store.dispatch(setCharacterization(result.data.Data))
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'GetAreas':
            axios.post(`https://localhost:44323/api/placement/GetPlacement?placementId=${action.placementID}`, action.list)
                .then(result => {
                    console.log(result);
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'SAVE_TUTOR_CONSTRAINT':
            action.list.map(x => {
                console.log(x);
                axios.put(`https://localhost:44323/api/tutorCharacterizationConstraint/Put`,
                    { 'TutorCharacterizationConstrainId': 0, 'CharacterizationConstarintId': x.CharacterizationConstrainId, 'TutorId': x.UserId, 'Status': x.Status })
                    .then(result => {
                        console.log(result);
                        store.dispatch(setPreference(result.data.Data));
                    })
                    .catch(error => {
                        console.log(error);
                    })
            })
            break;
        case 'SAVE_APPR_CONSTRAINT':
            action.list.map(x => {
                console.log(x);
                axios.put(`https://localhost:44323/api/CharacterizationConstraintApprentice/Put`,
                    { 'ApprenticeCharacterizationConstraintId': 0, 'ApprenticeId': x.ApprenticeID, 'CharacterizationConstraintId': x.CharacterizationConstrainId, 'Status': x.Status })
                    .then(result => {
                        console.log(result);
                        store.dispatch(setPreference(result.data.Data));
                    })
                    .catch(error => {
                        console.log(error);
                    })
            })
            break;
        case 'PLACEMENT':
            axios.post(`https://localhost:44323/api/placement/Post`, { PlacementID: action.payload.PlacementId, 'PlacementName': action.payload.PlacementName, 'Date': action.payload.Date })
                .then(result => {
                    console.log(result);
                })
                .catch(error => {
                    console.log(error);
                })
            break;
            case 'P_ID':
                axios.get(`https://localhost:44323/api/placement/GetByName/${action.payload}`)
                .then(result => {
                    console.log(result);
                    store.dispatch(setPlacementId(result.data.Data));
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'P_NAME':
            axios.get(`https://localhost:44323/api/placement/GetAllPlacement`)
                .then(result => {
                    console.log(result);
                    store.dispatch(setPName(result.data.Data));
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'PLACEMENT_ID_BY_USERID':
            axios.get(`https://localhost:44323/api/TutorForApprentice/GetPlacementByUser/${action.value.userId}`)
                .then(result => {
                    console.log(result);
                    store.dispatch(setPlacementId(result.data.Data));
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'ADD_AREA':
            axios.post(`https://localhost:44323/api/area/Post`, { 'AreaName': action.value.AreaName, 'CityId': action.value.CityId })
                .then(result => {
                    console.log(result);
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'CITY_DATA_MID':
            axios.get(`https://localhost:44323/api/city/Get`)
                .then(result => {
                    console.log(result);
                    store.dispatch(setCities(result.data.Data));
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'AREA_DATA_MID':
            store.dispatch(setCityN(action.payload.payload));
            store.dispatch(setCityId(action.payload.value))
            axios.get(`https://localhost:44323/api/area/GetAreaByCityId/${action.payload.value}`)
                .then(result => {
                    console.log(result);
                    store.dispatch(setAreas(result.data.Data));
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'ADD_CONSTRAINTS':
            //api/PattrenConstaraint/GetConstraintIdByName/{constarintName}
            axios.post(`https://localhost:44323/api/Constraint/Post`, { 'ConstraintName': action.Value, 'Placement': action.placementID })
                .then(result => {
                    console.log(result);
                    // store.dispatch(setConstraintID(result.data.Data));
                    axios.post(`https://localhost:44323/api/patternConstraint/Post`, { 'ConstarintId': result.data.Data, 'ConstraintPatternType': action.select })
                        .then(result2 => {
                            console.log(result2);
                            action.list.map(x => {
                                console.log(x);
                                axios.post(`https://localhost:44323/api/characterizationConstraints/Post`,
                                    { 'CharacterizationConstraintsId': x.CharacterizationConstraintsId, 'ConstarintId': x.ConstarintId, 'IsOpposit': x.IsOpposit, 'Value': x.Value })
                                    .then(result3 => {
                                        // console.log(action.list);
                                        console.log(result3);
                                    })
                                    .catch(error3 => {
                                        console.log(error3);
                                    })
                            })

                        })
                        .catch(error2 => {
                            console.log(error2);
                        })
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        case 'PREFERENCE':
            axios.get(`https://localhost:44323/api/preference/Get`)
                .then(result => {
                    console.log(result);
                    store.dispatch(setPreference(result.data.Data));
                })
                .catch(error => {
                    console.log(error);
                })
            break;
        
          
        
        case 'SAVE_APPR_PREFERENCE':
            action.list.map(x => {
                    axios.put(`https://localhost:44323/api/preferenceApprentice/updatePreferenceApprentice`,
                        {'PreferenceApprenticeID': 0, 'PreferenceID': x.preferenceId, 'ApprenticeID': x.apprentinceId, 'Status': x.status})
                        .then(result => {
                            console.log(result);
                        })
                        .catch(error => {
                            console.log(error);
                        })
            })
            break;
        case 'SAVE_APPR_CONSTRAINT':
            action.list.map(x => {
                console.log(x);
                axios.put(`https://localhost:44323/api/CharacterizationConstraintApprentice/Put`,
                    { 'ApprenticeCharacterizationConstraintId': x.CharacterizationConstrainId, 'ApprenticeId': x.ApprenticeID, 'CharacterizationConstraintId': x.ConstraintID, 'Status': x.Status })
                    .then(result => {
                        console.log(result);
                        store.dispatch(setPreference(result.data.Data));
                    })
                    .catch(error => {
                        console.log(error);
                    })
            })
            break;
        case 'SAVE_TUTOR_PREFERENCE':
            action.list.map(x => {
                axios.put(`https://localhost:44323/api/PreferenceTutor/Put`,
                    { 'PreferenceForTutorID':0,'PreferenceID': x.preferenceId, 'TutorID': x.tutorId, 'Status': x.status })
                    .then(result => {
                        console.log(result);
                    })
                    .catch(error => {
                        console.log(error);
                    })
    })
            break;
            case 'TBL1':
                axios.get(`https://localhost:44323/api/placement/GetTutorsResult/${action.placement}`)
                .then(result => {
                    console.log(result);
                    store.dispatch(setAllTutors(result.data.Data));
                })
                .catch(error => {
                    console.log(error);
                })
                break;
                case 'TBL2':
                axios.get(`https://localhost:44323/api/placement/GetApprenticeResult/${action.placement}`)
                .then(result => {
                    console.log(result);
                    store.dispatch(setAllApprentices(result.data.Data));
                })
                .catch(error => {
                    console.log(error);
                })
                break;
                case 'TBL3':
                axios.get(`https://localhost:44323/api/placement/GetScoreResult/${action.placement}`)
                .then(result => {
                    console.log(result);
                    store.dispatch(setMarks(result.data.Data));
                })
                .catch(error => {
                    console.log(error);
                })
                break;
                case 'TOOL':
                    axios.get(`https://localhost:44323/api/placement/GetTolTip/${action.placement}`)
                    .then(result => {
                        console.log(result);
                        store.dispatch(setTool(result.data.Data));
                    })
                    .catch(error => {
                        console.log(error);
                    })
                    break;
        case 'LOG':
            store.dispatch(setIsLog(true));
            break;
        case 'I_AM_MANAGER':
            store.dispatch(setIsManager(true));
            break;
        case 'I_AM_TUTOR':
            store.dispatch(setIsTutor(true));
            break;
        case 'I_AM_APPR':
            store.dispatch(setIsAppr(true));
            break;
        case 'PLACEMENT_ID':
            store.dispatch(setPlacementId(action.value));
            break;
        default:
            break;
    }
    return next(action);
}
export default middleware;