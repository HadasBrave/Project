import { createSlice } from '@reduxjs/toolkit';

const generalReducer = createSlice({
    name: 'generalReducer',
    initialState: {
        userData:null,
        cities: [],
        cityN:null,
        cityId:null,
        pName: null,
        islog: false,
        isManager: false,
        isTutor: false,
        isAppr: false,
        isLog: false,
        areas:null,
        constraints:null,
        placementId: 0,
        character:null,
        characterization:null,
        preference:null,
        constraintID:null,
        allCharacterization: [],
        ApprenticeID: 1,
        TutorID:null,
        allApprentices:null,
        allTutors:null,
        marks:null,
        tool:null,
        addAreaPage:false,
    },
    reducers: {
        setUserData(state, action) {
            state.userData = action.payload;
        },
        setApprenticeID(state, action) {
            state.ApprenticeID = action.payload;
        },
        setTutorID(state, action) {
            state.TutorID = action.payload;
        },
        setCities(state, action) {
            state.cities = action.payload;
        },
        setCityN(state, action) {
            state.cityN = action.payload;
        },
        setCityId(state, action) {
            state.cityId = action.payload;
        },
        setPName(state, action) {
            state.pName = action.payload;
        },
        setConstraints(state,action){
            state.constraints=action.payload;
        },
        setIslog(state, action) {
            state.islog = action.payload;
        },
        setPlacementId(state, action) {
            state.placementId = action.payload;
        },
        setIsManager(state, action) {
            state.isManager = action.payload;
        },
        setConstraintID(state,action){
            state.constraintID=action.payload;
        },
        setIsTutor(state, action) {
            state.isTutor = action.payload;
        },
        setIsAppr(state, action) {
            state.isAppr = action.payload;
        },
        setIsLog(state, action) {
            state.isLog = action.payload;
        },
        setAreas(state, action) {
            state.areas = action.payload;
        },
        setPreference(state,action){
            state.preference=action.payload;
        },
        setCharacterization(state,action){
            state.characterization=action.payload;
        },
        setAllCharacterization(state,action){
            state.allCharacterization=action.payload;
        },
        setPResult(state,action){
            state.pResult=action.payload;
        },
        setPAllResult(state,action){
            state.pAllResult=action.payload;
        },
        setAllApprentices(state,action){
            state.allApprentices=action.payload;
        },
        setAllTutors(state,action){
            state.allTutors=action.payload;
        },
        setMarks(state,action){
            state.marks=action.payload;
        },
        setTool(state,action){
            state.tool=action.payload;
        },
        setAddAreaPage(state,action){
            state.addAreaPage=action.payload;
        },
    }
})

export const {
   setUserData ,setApprenticeID,setTutorID,setCityN ,setConstraintID ,setCityId, setAreas,constraints, setCities,setConstraints ,setPreference ,setPlacementId, setPName,
   setIslog, setIsManager, setIsTutor, setIsAppr,setIsLog,setCharacterization, setAllCharacterization,setAllApprentices,setAllTutors,setMarks,setTool,setAddAreaPage,
} = generalReducer.actions;

export default generalReducer.reducer;