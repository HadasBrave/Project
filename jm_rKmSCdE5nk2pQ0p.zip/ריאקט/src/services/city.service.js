import axios from "axios";
import { setCities } from '../reducer';

class cityService {
    constructor() {
        this.url = 'https://localhost:44323/api';
    }


    // cityDataMid = store => action => next => {
    //     if (action.type === 'CITY_DATA_MID') {
    //         axios.get(`${this.url}/city/Get`)
    //             .then(result => {
    //                 console.log(result);
    //                 store.dispatch(setCities(result.data));
    //                 // values.setCities(result.data);
    //                 // setCities(result.data);
    //                 // set(result.data);
    //             })
    //             .catch(error => {
    //                 console.log(error);
    //             })
    //     }
    //     next(action);
    // }

    cityData = () => {
        axios.get(`${this.url}/city/Get`)
            .then(result => {
                console.log(result);

                // values.setCities(result.data);
                // setCities(result.data);
                // set(result.data);
            })
            .catch(error => {
                console.log(error);
            })
    }
}
const cityDataMid = store => action => next => {
    if (action.type === 'CITY_DATA_MID') {
        axios.get(`${this.url}/city/Get`)
            .then(result => {
                console.log(result);
                store.dispatch(setCities(result.data));
                // values.setCities(result.data);
                // setCities(result.data);
                // set(result.data);
            })
            .catch(error => {
                console.log(error);
            })
    }
    next(action);
}
export default new cityService();