import axios from "axios";

class mentorService {
    constructor() {
        this.url = 'https://localhost:44323/api';
    }
    mentorProperties = (values) => {
        axios.get(`${this.url}/User/GetUser/${values.userName}/${values.password}`)
            .then(result => {
                console.log(result);
            })
            .catch(error => {
                console.log(error);
            })
    }
}
export default new mentorService();
//  לשלוח דרך נוספת
// mentorProperties = (values) => {
//     axios.post(`${this.url}/User/GetUser/${values.userName}/${values.password}`)
//         .then((response)=>{
// return response.data;});
// }
// לקבל דרך נוספת
// mentorProperties = (values) => {
//     axios.get(`${this.url}/User/GetUser/${values.userName}/${values.password}`)
//         .then(({data})=>data);
// }