import axios from "axios";

class placementService {
    constructor() {
        this.url = 'https://localhost:44323/api';
    }
    placement = (values) => {
        axios.post(`${this.url}/placement/Post/${values.PlacementName,values.date}`)
            .then(result => {
                console.log(result);
                // set(result.data);
            })
            .catch(error => {
                console.log(error);
            })
    }
}
export default new placementService();