import axios from "axios";

class UserService {
    constructor() {
        this.url = 'https://localhost:44323/api';
    }
    login = (values) => {
        axios.post(`${this.url}/user/GetUser/${values.userName}/${values.password}`)
            .then(result => {
                console.log(result);
            })
            .catch(error => {
                console.log(error);
            })
    }
    // signIn = (values) => {
    //     axios.post(`${this.url}/user/GetUser/${values.userName}/${values.password}`)
    //         .then(result => {
    //             console.log(result);
    //         })
    //         .catch(error => {
    //             console.log(error);
    //         })
    // }
    addArea = (values) => {
        axios.post(`${this.url}/area/Post/${values.AreaName}`)
            .then(result => {
                console.log(result);
            })
            .catch(error => {
                console.log(error);
            })
    }
}
export default new UserService();