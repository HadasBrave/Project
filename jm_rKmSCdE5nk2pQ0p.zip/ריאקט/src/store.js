import { configureStore } from '@reduxjs/toolkit'
import middleware from './middleware'
import generalReducer from './reducer'

const reducer = generalReducer;
const store = configureStore({
    reducer: {
        generalReducer: reducer,
    },
    middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(middleware),
})

export default store;
